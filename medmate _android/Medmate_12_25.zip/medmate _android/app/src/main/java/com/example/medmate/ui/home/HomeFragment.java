package com.example.medmate.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.medmate.R;
import com.example.medmate.bookingviewactivity;
import com.example.medmate.databinding.FragmentHomeBinding;
import com.example.medmate.doctorlistactivity;
import com.example.medmate.responseactivity;

public class HomeFragment extends Fragment {
    CardView dbook,docbook1;


    private FragmentHomeBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();


        docbook1=root.findViewById(R.id.bres);
        dbook=root.findViewById(R.id.docbook);



        dbook.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(getActivity(), doctorlistactivity.class);
                startActivity(in);
            }
        });

        docbook1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(getActivity(), responseactivity.class);
                startActivity(in);
            }
        });




        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
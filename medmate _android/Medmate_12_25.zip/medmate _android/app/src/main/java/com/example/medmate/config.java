package com.example.medmate;

public interface config {

    String baseurl="http://192.168.1.75/medmate/";
}
